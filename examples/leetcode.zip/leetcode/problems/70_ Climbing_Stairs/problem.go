package problems

func climbStairs(n int) int {
	return 0
}
