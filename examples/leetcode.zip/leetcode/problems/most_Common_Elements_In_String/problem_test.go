package most_Common_Elements_In_String

import (
	"reflect"
	"testing"
)

func Test_mostCommonElementsInAString(t *testing.T) {
	type args struct {
		str string
	}
	tests := []struct {
		name string
		args args
		want map[string]int
	}{
		{
			name: "happy path 1",
			args: args{str: "ioioioiopp"},
			want: map[string]int{
				"i": 4,
				"o": 4,
			},
		},
		{
			name: "happy path 1",
			args: args{str: "dddpppmmmccccccccgggggggg"},
			want: map[string]int{
				"c": 8,
				"g": 8,
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := mostCommonElementsInAString(tt.args.str); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("mostCommonElementsInAString() = %v, want %v", got, tt.want)
			}
		})
	}
}
