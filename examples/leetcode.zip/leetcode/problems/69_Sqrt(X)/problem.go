package problems

func mySqrt(x int) int {
	return 0
}
